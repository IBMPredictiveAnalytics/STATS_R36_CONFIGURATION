args <- commandArgs(TRUE)
pkg <- args[1]

if (file.access(.Library, mode=2) == 0) {
    libraryPath = .Library
} else {
    libraryPath = Sys.getenv("R_LIBS_USER")
}

if (pkg == "libraryPath") {
    print(libraryPath)
} else {
    mkdirs <- function(dir) {
        if (!dir.exists(dir)) {
            mkdirs(dirname(dir))
            dir.create(dir)
        }
    }
    
    mkdirs(libraryPath)
    .libPaths(c(libraryPath, .libPaths()))

    if (.Platform$pkgType == "source") {
        install.packages(pkg, lib=.libPaths()[1], repos=NULL, type=.Platform$pkgType, INSTALL_opts="--html --no-test-load")
    } else {
        install.packages(pkg, lib=.libPaths()[1], repos=NULL, type=.Platform$pkgType)
    }
}
